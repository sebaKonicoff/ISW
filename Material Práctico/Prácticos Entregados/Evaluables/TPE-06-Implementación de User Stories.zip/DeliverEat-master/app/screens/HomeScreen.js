import React from "react";
import { StyleSheet, View } from "react-native";
import CategorySelector from "../components/CategorySelector";
import FoodList from "../components/FoodList";
import Screen from "../components/Screen";
import Text from "../components/Text";
import TopNav from "../components/TopNav";
import colors from "../config/colors";

function HomeScreen({ navigation }) {
  return (
    <Screen separate style={styles.screen}>
      <View style={styles.top}>
        <TopNav leftIcon="map-marker-alt" rightIcon="shopping-cart" location />
      </View>
      <View style={styles.message}>
        <Text
          style={{
            fontSize: 30,
            lineHeight: 35,
            fontFamily: "Roboto_700Bold",
            // temporal
            marginBottom: 15,
            marginTop: 25,
          }}
        >
          ¿Qué querés hoy?
        </Text>
      </View>
      <CategorySelector navigation={navigation} />
      <View style={styles.list}>
        <FoodList />
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  screen: {
    backgroundColor: colors.transparent,
  },
  message: {
    backgroundColor: colors.transparent,
    paddingHorizontal: 20,
  },
  top: {
    paddingHorizontal: 20,
  },
  list: {
    paddingHorizontal: 20,
    flex: 1,
  },
});

export default HomeScreen;
